// sensors.h
#pragma once

// void udpBegin();
// void maybeSendUdpPacket();
// void udpListen();